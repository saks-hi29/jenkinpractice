package com.verizon.mavencucumberapp1;

import io.cucumber.java.en.*;
import src.test.java.belly.java;
import static org.junit.jupiter.api.Assertions.*;

public class StepDefinitions {

    @Given("I have {int} cukes in my belly")
    public void I_have_cukes_in_my_belly(int cukes) {
    	belly belly = new belly();
    	belly.eat(cukes);
    }

    @When("I will wait 1 hour")
    public void allStepDefinitionsAreImplemented() {
    	belly belly = new belly();
    	belly.waitStep();
    	
    }

    @Then("my belly should growl")
    public void theScenarioPasses() {
    	belly belly = new belly();
    	belly.endProcess();
    }

}
