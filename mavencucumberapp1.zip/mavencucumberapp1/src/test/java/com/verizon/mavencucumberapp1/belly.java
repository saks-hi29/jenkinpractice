package com.verizon.mavencucumberapp1;

public class belly {
	public void eat(int cukes) {
		System.out.println("step started");
	}
	
	public void waitStep() {
		System.out.println("waiting after step1");
	}
	
	public void endProcess() {
		System.out.println("all steps are completed");
	}

}
